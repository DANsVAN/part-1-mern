import "./Map.css";
///////////////////////// they said to skip if you do bot have a credit card
function Map(props) {
  return <div></div>;
}

export default Map;
