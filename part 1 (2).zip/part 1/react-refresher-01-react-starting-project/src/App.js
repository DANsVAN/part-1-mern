import React, { useState } from "react";
import "./App.css";
import GoalList from "./components/GoalList";
import NewGoal from "./components/NewGoal/NewGoal.js";
const App = () => {
  function addNewGoalHandler(newGoal) {
    setCourseGoals((prevState) => {
      return prevState.concat(newGoal);
    });

    console.log(courseGoals);
  }

  const [courseGoals, setCourseGoals] = useState([
    { id: "cg1", text: "Finish the course" },
    { id: "cg2", text: "learn!" },
    { id: "cg3", text: "learn!!" },
    { id: "cg4", text: "learn!!!" },
  ]);
  return (
    <div className="Course-Goals">
      <h2>Course Goals</h2>
      <NewGoal addNewGoalHandler={addNewGoalHandler}></NewGoal>
      <GoalList allCourseGoals={courseGoals}></GoalList>
    </div>
  );
};

export default App;
