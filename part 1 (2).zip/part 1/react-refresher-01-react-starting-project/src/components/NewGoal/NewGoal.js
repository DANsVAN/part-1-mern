import React from "react";
import "./NewGoal.css";
import { useState } from "react";
export default function NewGoal({ addNewGoalHandler }) {
  const [enteredText, setEnteredText] = useState("");
  function onInput(keyPress) {
    console.log(keyPress.target.value);
    setEnteredText(keyPress.target.value);
  }
  function addGoalHandler(event) {
    event.preventDefault();
    const newGoal = {
      id: Math.random().toString(),
      text: enteredText,
    };
    setEnteredText("");
    addNewGoalHandler(newGoal);
  }

  return (
    <form className="new-goal" onSubmit={(event) => addGoalHandler(event)}>
      <input
        type="text"
        onChange={(keyPress) => {
          onInput(keyPress);
        }}
        value={enteredText}
      />
      <button type="submit">Add Goal</button>
    </form>
  );
}
