import { useState, useEffect } from "react";
export default function GoalList({ allCourseGoals }) {
  return (
    <ul className="goal-list">
      {allCourseGoals.map((goal) => {
        return <li key={goal.id}>{goal.text}</li>;
      })}
    </ul>
  );
}
